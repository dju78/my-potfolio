# Daramola Joseph Omoyele — Portfolio (Netlify-ready)

## What you get
- Single-page professional portfolio site (fast, simple, recruiter-friendly)
- Project highlight includes **DEAP Tax Compliance**: https://deaptaxcompliance.netlify.app/
- ORCID link: https://orcid.org/0009-0006-0347-0499
- Downloadable CV: `cv.docx`
- Contact form configured for **Netlify Forms**

## Deploy on Netlify (2 options)

### Option A — Drag & Drop
1. Zip the folder contents (or use the provided zip).
2. Go to Netlify Drop and drag the zip.
3. Done.

### Option B — Git deploy
1. Push this folder to a GitHub repo.
2. In Netlify: **Add new site** → **Import from Git**.
3. Build command: *(leave blank)*
4. Publish directory: `.`

## Update content
Open `index.html` and edit:
- Summary text
- Projects
- Experience
- Publications

CSS lives in `assets/style.css`.
JS lives in `assets/main.js`.
