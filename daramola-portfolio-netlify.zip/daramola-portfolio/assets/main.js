(function(){
  const $ = (s, r=document) => r.querySelector(s);
  const $$ = (s, r=document) => Array.from(r.querySelectorAll(s));

  // Mobile nav
  const navBtn = $('#navToggle');
  const nav = $('#siteNav');
  if(navBtn && nav){
    navBtn.addEventListener('click', () => {
      const open = nav.getAttribute('data-open') === 'true';
      nav.setAttribute('data-open', open ? 'false' : 'true');
      navBtn.setAttribute('aria-expanded', open ? 'false' : 'true');
    });
  }

  // Smooth scroll
  $$('a[href^="#"]').forEach(a => {
    a.addEventListener('click', (e) => {
      const id = a.getAttribute('href');
      if(!id || id === '#') return;
      const el = $(id);
      if(!el) return;
      e.preventDefault();
      el.scrollIntoView({behavior:'smooth', block:'start'});
      if(nav) nav.setAttribute('data-open','false');
      if(navBtn) navBtn.setAttribute('aria-expanded','false');
      history.replaceState(null, '', id);
    });
  });

  // Copy-to-clipboard for quick contact
  const copyEls = $$('[data-copy]');
  copyEls.forEach(btn => {
    btn.addEventListener('click', async () => {
      const v = btn.getAttribute('data-copy') || '';
      try{
        await navigator.clipboard.writeText(v);
        btn.textContent = 'Copied';
        setTimeout(()=>btn.textContent='Copy', 900);
      }catch{
        // no-op
      }
    });
  });

  // Year
  const y = $('#year');
  if(y) y.textContent = String(new Date().getFullYear());
})();
