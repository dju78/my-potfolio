# Instructions to Push Portfolio to GitHub

## Your portfolio is ready! Follow these steps:

### Step 1: Create a New Repository on GitHub
1. Go to https://github.com/new
2. Repository name: `portfolio` (or any name you prefer)
3. Description: "Professional Portfolio - Economist & Data Analyst"
4. Choose "Public" visibility
5. **DO NOT** initialize with README, .gitignore, or license (we already have these)
6. Click "Create repository"

### Step 2: Get Your Repository Files
Your portfolio files are ready in a Git repository. You'll need to:

**Option A: Download and push from your local machine**
1. Download the `index.html` and `README.md` files from the outputs
2. On your computer, create a folder for your portfolio
3. Copy both files into that folder
4. Open terminal/command prompt in that folder
5. Run these commands:

```bash
git init
git add .
git commit -m "Initial commit: Professional portfolio website"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/portfolio.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your actual GitHub username.

**Option B: Use GitHub's web interface**
1. After creating the repository, click "uploading an existing file"
2. Drag and drop both `index.html` and `README.md`
3. Commit the files

### Step 3: Enable GitHub Pages (to host your portfolio online)
1. Go to your repository on GitHub
2. Click "Settings" tab
3. Click "Pages" in the left sidebar
4. Under "Source", select "main" branch
5. Click "Save"
6. Your portfolio will be live at: `https://YOUR-USERNAME.github.io/portfolio/`

### Step 4: Custom Domain (Optional)
If you want a custom domain like `daramola-omoyele.com`:
1. Buy a domain from a registrar (Namecheap, Google Domains, etc.)
2. In GitHub Pages settings, add your custom domain
3. Update your domain's DNS settings to point to GitHub Pages

### Files Included:
- `index.html` - Your complete portfolio website
- `README.md` - Repository documentation

### Need Help?
- GitHub Pages Guide: https://pages.github.com/
- Custom Domain Guide: https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site

---

Your portfolio includes:
✓ Professional experience and credentials
✓ Publications and media contributions
✓ DEAP Tax Compliance project
✓ Research focus areas
✓ Contact information
✓ Responsive design
✓ ORCID integration
