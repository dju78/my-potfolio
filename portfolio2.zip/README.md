# Professional Portfolio - Daramola Joseph Omoyele

## Economist | Data Analyst | Policy Specialist

This repository contains my professional portfolio website showcasing my work in applied econometrics, regulatory analytics, and evidence-based policymaking.

### About Me

I am an economist and data analyst specializing in:
- Applied Econometrics (Panel Data, Time Series, Regression)
- Regulatory Analytics & Compliance (RegTech)
- Public Policy & Economic Analysis
- Data Visualization & Decision Support Systems

### Portfolio Contents

- **Professional Experience**: 15+ years in public sector analysis and consulting
- **Education**: MSc Economics with Data Analytics (University of Essex), BSc Economics (University of Ilorin)
- **Publications**: Books, policy commentary, and media contributions
- **Featured Projects**: DEAP Tax Compliance System and other data-driven applications
- **Research Focus**: Housing affordability, taxation, digital governance, and electoral integrity

### Contact

- **Email**: dju78@yahoo.com | 1978dju@gmail.com
- **Location**: Colchester, Essex, United Kingdom
- **ORCID**: [0009-0006-0347-0499](https://orcid.org/0009-0006-0347-0499)

### Technologies Used

- HTML5
- CSS3 (Custom styling with CSS Grid and Flexbox)
- Vanilla JavaScript
- Google Fonts (Cormorant Garamond, Work Sans)

### View Portfolio

Visit the live portfolio at: [Your GitHub Pages URL will go here]

---

© 2025 Daramola Joseph Omoyele. All rights reserved.
